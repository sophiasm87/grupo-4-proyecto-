/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class Clases {

    private Trabajador trabajadorYoga1;
    private Trabajador trabajadorYoga2;
    private Trabajador trabajadorYoga3;
    private Trabajador trabajadorYoga4;
    private Trabajador trabajadorYoga5;

    private Trabajador trabajadorBaile1;
    private Trabajador trabajadorBaile2;
    private Trabajador trabajadorBaile3;
    private Trabajador trabajadorBaile4;
    private Trabajador trabajadorBaile5;

    public Clases() {
        // Constructor vacío
    }

    public boolean inscribirEnClaseYoga(Trabajador nuevoTrabajador) {

        if (trabajadorYoga1 != null && trabajadorYoga1.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorYoga2 != null && trabajadorYoga2.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorYoga3 != null && trabajadorYoga3.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorYoga4 != null && trabajadorYoga4.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorYoga5 != null && trabajadorYoga5.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }

        if (trabajadorYoga1 == null) {
            trabajadorYoga1 = nuevoTrabajador;
            return true;
        }
        if (trabajadorYoga2 == null) {
            trabajadorYoga2 = nuevoTrabajador;
            return true;
        }
        if (trabajadorYoga3 == null) {
            trabajadorYoga3 = nuevoTrabajador;
            return true;
        }
        if (trabajadorYoga4 == null) {
            trabajadorYoga4 = nuevoTrabajador;
            return true;
        }
        if (trabajadorYoga5 == null) {
            trabajadorYoga5 = nuevoTrabajador;
            return true;
        }

        return false; // ya no hay espacio en yoga
    }

    public boolean inscribirEnClaseBaile(Trabajador nuevoTrabajador) {

        if (trabajadorBaile1 != null && trabajadorBaile1.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorBaile2 != null && trabajadorBaile2.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorBaile3 != null && trabajadorBaile3.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorBaile4 != null && trabajadorBaile4.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }
        if (trabajadorBaile5 != null && trabajadorBaile5.getCodigoTrabajador() == nuevoTrabajador.getCodigoTrabajador()) {
            return false;
        }

        if (trabajadorBaile1 == null) {
            trabajadorBaile1 = nuevoTrabajador;
            return true;
        }
        if (trabajadorBaile2 == null) {
            trabajadorBaile2 = nuevoTrabajador;
            return true;
        }
        if (trabajadorBaile3 == null) {
            trabajadorBaile3 = nuevoTrabajador;
            return true;
        }
        if (trabajadorBaile4 == null) {
            trabajadorBaile4 = nuevoTrabajador;
            return true;
        }
        if (trabajadorBaile5 == null) {
            trabajadorBaile5 = nuevoTrabajador;
            return true;
        }

        return false; 
    }

    public boolean eliminarDeClasesPorCodigo(int codigoTrabajador) {

        if (trabajadorYoga1 != null && trabajadorYoga1.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorYoga1 = null;
            return true;
        }
        if (trabajadorYoga2 != null && trabajadorYoga2.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorYoga2 = null;
            return true;
        }
        if (trabajadorYoga3 != null && trabajadorYoga3.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorYoga3 = null;
            return true;
        }
        if (trabajadorYoga4 != null && trabajadorYoga4.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorYoga4 = null;
            return true;
        }
        if (trabajadorYoga5 != null && trabajadorYoga5.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorYoga5 = null;
            return true;
        }

        if (trabajadorBaile1 != null && trabajadorBaile1.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorBaile1 = null;
            return true;
        }
        if (trabajadorBaile2 != null && trabajadorBaile2.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorBaile2 = null;
            return true;
        }
        if (trabajadorBaile3 != null && trabajadorBaile3.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorBaile3 = null;
            return true;
        }
        if (trabajadorBaile4 != null && trabajadorBaile4.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorBaile4 = null;
            return true;
        }
        if (trabajadorBaile5 != null && trabajadorBaile5.getCodigoTrabajador() == codigoTrabajador) {
            trabajadorBaile5 = null;
            return true;
        }

        return false;
    }

    public String obtenerTextoListaYoga() {

        String texto = "Personas inscritas en clase de Yoga:\n";

        if (trabajadorYoga1 != null) {
            texto = texto + trabajadorYoga1.getCodigoTrabajador() + " - " + trabajadorYoga1.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorYoga2 != null) {
            texto = texto + trabajadorYoga2.getCodigoTrabajador() + " - " + trabajadorYoga2.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorYoga3 != null) {
            texto = texto + trabajadorYoga3.getCodigoTrabajador() + " - " + trabajadorYoga3.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorYoga4 != null) {
            texto = texto + trabajadorYoga4.getCodigoTrabajador() + " - " + trabajadorYoga4.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorYoga5 != null) {
            texto = texto + trabajadorYoga5.getCodigoTrabajador() + " - " + trabajadorYoga5.getNombreCompletoTrabajador() + "\n";
        }

        return texto;
    }

    public String obtenerTextoListaBaile() {

        String texto = "Personas inscritas en clase de Baile:\n";

        if (trabajadorBaile1 != null) {
            texto = texto + trabajadorBaile1.getCodigoTrabajador() + " - " + trabajadorBaile1.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorBaile2 != null) {
            texto = texto + trabajadorBaile2.getCodigoTrabajador() + " - " + trabajadorBaile2.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorBaile3 != null) {
            texto = texto + trabajadorBaile3.getCodigoTrabajador() + " - " + trabajadorBaile3.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorBaile4 != null) {
            texto = texto + trabajadorBaile4.getCodigoTrabajador() + " - " + trabajadorBaile4.getNombreCompletoTrabajador() + "\n";
        }
        if (trabajadorBaile5 != null) {
            texto = texto + trabajadorBaile5.getCodigoTrabajador() + " - " + trabajadorBaile5.getNombreCompletoTrabajador() + "\n";
        }

        return texto;
    }
}

