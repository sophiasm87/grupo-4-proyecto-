/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
import javax.swing.*;
import java.awt.*;

public class Proyecto4 {
private JFrame ventanaPrincipal;
    private JPanel panelCentral;
    private CardLayout controladorPaneles;

    private ControlEmpresa controlEmpresa;
    private Clases moduloClases;
    private Gimnasio moduloGimnasio;
    private Cine moduloCine;
    private Cafeteria moduloCafeteria;

    private VentanaTrabajadores ventanaTrabajadores;
    private VentanaClases ventanaClases;
    private VentanaGym ventanaGimnasio;
    private VentanaCine ventanaCine;
    private VentanaCafeteria ventanaCafeteria;

    public static void main(String[] args) {
        // No usamos args para nada, solo está porque Java lo pide
        new Proyecto4();
    }

    public Proyecto4() {

        controlEmpresa = new ControlEmpresa();
        moduloClases = new Clases();
        moduloGimnasio = new Gimnasio();
        moduloCine = new Cine();
        moduloCafeteria = new Cafeteria();

        ventanaTrabajadores = new VentanaTrabajadores(controlEmpresa);
        ventanaClases = new VentanaClases(controlEmpresa, moduloClases);
        ventanaGimnasio = new VentanaGym(controlEmpresa, moduloGimnasio);
        ventanaCine = new VentanaCine(controlEmpresa, moduloCine);
        ventanaCafeteria = new VentanaCafeteria(controlEmpresa, moduloCafeteria);

        ventanaPrincipal = new JFrame("Proyecto 4 - Sistema de Actividades");
        ventanaPrincipal.setSize(900, 600);
        ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaPrincipal.setLocationRelativeTo(null);
        ventanaPrincipal.setLayout(new BorderLayout());

        JPanel panelMenu = new JPanel();
        panelMenu.setPreferredSize(new Dimension(180, 0));
        panelMenu.setLayout(new GridLayout(6, 1, 5, 5));

        JButton botonTrabajadores = new JButton("Trabajadores");
        JButton botonClases = new JButton("Clases");
        JButton botonGimnasio = new JButton("Gimnasio");
        JButton botonCine = new JButton("Cine");
        JButton botonCafeteria = new JButton("Cafetería");
        JButton botonSalir = new JButton("Salir");

        panelMenu.add(botonTrabajadores);
        panelMenu.add(botonClases);
        panelMenu.add(botonGimnasio);
        panelMenu.add(botonCine);
        panelMenu.add(botonCafeteria);
        panelMenu.add(botonSalir);

        ventanaPrincipal.add(panelMenu, BorderLayout.WEST);

        controladorPaneles = new CardLayout();
        panelCentral = new JPanel(controladorPaneles);

        panelCentral.add(ventanaTrabajadores.obtenerPanel(), "TRABAJADORES");
        panelCentral.add(ventanaClases.obtenerPanel(), "CLASES");
        panelCentral.add(ventanaGimnasio.obtenerPanel(), "GIMNASIO");
        panelCentral.add(ventanaCine.obtenerPanel(), "CINE");
        panelCentral.add(ventanaCafeteria.obtenerPanel(), "CAFETERIA");

        ventanaPrincipal.add(panelCentral, BorderLayout.CENTER);

        botonTrabajadores.addActionListener(e -> controladorPaneles.show(panelCentral, "TRABAJADORES"));
        botonClases.addActionListener(e -> controladorPaneles.show(panelCentral, "CLASES"));
        botonGimnasio.addActionListener(e -> controladorPaneles.show(panelCentral, "GIMNASIO"));
        botonCine.addActionListener(e -> controladorPaneles.show(panelCentral, "CINE"));
        botonCafeteria.addActionListener(e -> controladorPaneles.show(panelCentral, "CAFETERIA"));
        botonSalir.addActionListener(e -> ventanaPrincipal.dispose());


        controladorPaneles.show(panelCentral, "TRABAJADORES");

        ventanaPrincipal.setVisible(true);
    }
}

