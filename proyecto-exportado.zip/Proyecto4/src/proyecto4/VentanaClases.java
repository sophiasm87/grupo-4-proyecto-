/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class VentanaClases {

private JPanel panelSalida;
    private ControlEmpresa controlEmpresa;
    private Clases Clases;

    private JTextField campoCodigo;
    private JTextArea areaSalida;
    private JLabel etiquetaMensaje;

    public VentanaClases(ControlEmpresa controlEmpresaRecibido, Clases moduloClasesRecibido) {
        controlEmpresa = controlEmpresaRecibido;
        Clases = moduloClasesRecibido;
        crearComponentes();
    }

    private void crearComponentes() {
        panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel titulo = new JLabel("Módulo de Clases (Yoga y Baile)");
        titulo.setBounds(300, 10, 300, 30);
        panelSalida.add(titulo);

        JLabel labelCodigo = new JLabel("Código trabajador:");
        labelCodigo.setBounds(30, 60, 130, 25);
        panelSalida.add(labelCodigo);

        campoCodigo = new JTextField();
        campoCodigo.setBounds(160, 60, 80, 25);
        panelSalida.add(campoCodigo);

        JButton botonYoga = new JButton("Inscribir en Yoga");
        botonYoga.setBounds(260, 60, 140, 25);
        panelSalida.add(botonYoga);

        JButton botonBaile = new JButton("Inscribir en Baile");
        botonBaile.setBounds(420, 60, 140, 25);
        panelSalida.add(botonBaile);

        JButton botonEliminar = new JButton("Eliminar de clases");
        botonEliminar.setBounds(580, 60, 160, 25);
        panelSalida.add(botonEliminar);

        JButton botonVerListas = new JButton("Ver listas");
        botonVerListas.setBounds(30, 100, 140, 25);
        panelSalida.add(botonVerListas);

        etiquetaMensaje = new JLabel(" ");
        etiquetaMensaje.setBounds(200, 100, 600, 25);
        panelSalida.add(etiquetaMensaje);

        areaSalida = new JTextArea();
        areaSalida.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaSalida);
        scroll.setBounds(30, 140, 800, 380);
        panelSalida.add(scroll);

        botonYoga.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inscribirEnYoga();
            }
        });

        botonBaile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inscribirEnBaile();
            }
        });

        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarDeClases();
            }
        });

        botonVerListas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarListas();
            }
        });
    }

    private void inscribirEnYoga() {
        Trabajador trabajador = obtenerTrabajadorPorCampo();
        if (trabajador == null) {
            return;
        }
        boolean ok = Clases.inscribirEnClaseYoga(trabajador);
        if (ok) {
            etiquetaMensaje.setText("Trabajador inscrito en Yoga.");
        } else {
            etiquetaMensaje.setText("No se pudo inscribir en Yoga (sin espacio o repetido).");
        }
        mostrarListas();
    }

    private void inscribirEnBaile() {
        Trabajador trabajador = obtenerTrabajadorPorCampo();
        if (trabajador == null) {
            return;
        }
        boolean ok = Clases.inscribirEnClaseBaile(trabajador);
        if (ok) {
            etiquetaMensaje.setText("Trabajador inscrito en Baile.");
        } else {
            etiquetaMensaje.setText("No se pudo inscribir en Baile (sin espacio o repetido).");
        }
        mostrarListas();
    }

    private void eliminarDeClases() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código para eliminar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            boolean eliminado = Clases.eliminarDeClasesPorCodigo(codigo);
            if (eliminado) {
                etiquetaMensaje.setText("Trabajador eliminado de las clases.");
            } else {
                etiquetaMensaje.setText("El trabajador no estaba inscrito en ninguna clase.");
            }
            mostrarListas();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido.");
        }
    }

    private void mostrarListas() {
        String texto = "";
        texto = texto + Clases.obtenerTextoListaYoga() + "\n\n";
        texto = texto + Clases.obtenerTextoListaBaile();
        areaSalida.setText(texto);
    }

    private Trabajador obtenerTrabajadorPorCampo() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código del trabajador.");
            return null;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador trabajador = controlEmpresa.buscarTrabajadorPorCodigo(codigo);
            if (trabajador == null) {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
                return null;
            }
            return trabajador;
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
            return null;
        }
    }

    public JPanel obtenerPanel() {
        return panelSalida;
    }
}

