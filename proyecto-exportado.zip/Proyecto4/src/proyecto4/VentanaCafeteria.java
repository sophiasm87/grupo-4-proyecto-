/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author sophi
 */
public class VentanaCafeteria {
    private JPanel panelSalida;
    private ControlEmpresa controlEmpresa;
    private Cafeteria Cafeteria;

    private JTextField campoCodigo;
    private JTextField campoBebida;
    private JTextField campoHora;
    private JTextArea areaSalida;
    private JLabel etiquetaMensaje;

    public VentanaCafeteria(ControlEmpresa controlEmpresaRecibido, Cafeteria moduloCafeteriaRecibido) {
        controlEmpresa = controlEmpresaRecibido;
        Cafeteria = moduloCafeteriaRecibido;
        crearComponentes();
    }

    private void crearComponentes() {
        panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel titulo = new JLabel("Módulo de Cafetería");
        titulo.setBounds(360, 10, 200, 30);
        panelSalida.add(titulo);

        JLabel labelCodigo = new JLabel("Código trabajador:");
        labelCodigo.setBounds(30, 60, 130, 25);
        panelSalida.add(labelCodigo);

        campoCodigo = new JTextField();
        campoCodigo.setBounds(160, 60, 80, 25);
        panelSalida.add(campoCodigo);

        JLabel labelBebida = new JLabel("Bebida:");
        labelBebida.setBounds(260, 60, 60, 25);
        panelSalida.add(labelBebida);

        campoBebida = new JTextField();
        campoBebida.setBounds(320, 60, 150, 25);
        panelSalida.add(campoBebida);

        JLabel labelHora = new JLabel("Hora entrega:");
        labelHora.setBounds(490, 60, 90, 25);
        panelSalida.add(labelHora);

        campoHora = new JTextField();
        campoHora.setBounds(580, 60, 80, 25);
        panelSalida.add(campoHora);

        JButton botonRegistrar = new JButton("Registrar pedido");
        botonRegistrar.setBounds(30, 100, 150, 25);
        panelSalida.add(botonRegistrar);

        JButton botonCancelar = new JButton("Cancelar pedido");
        botonCancelar.setBounds(200, 100, 150, 25);
        panelSalida.add(botonCancelar);

        JButton botonVer = new JButton("Ver pedidos");
        botonVer.setBounds(370, 100, 130, 25);
        panelSalida.add(botonVer);

        etiquetaMensaje = new JLabel(" ");
        etiquetaMensaje.setBounds(30, 135, 700, 25);
        panelSalida.add(etiquetaMensaje);

        areaSalida = new JTextArea();
        areaSalida.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaSalida);
        scroll.setBounds(30, 170, 800, 330);
        panelSalida.add(scroll);

        botonRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarPedido();
            }
        });

        botonCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarPedido();
            }
        });

        botonVer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarPedidos();
            }
        });

        mostrarPedidos();
    }

    private Trabajador obtenerTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código del trabajador.");
            return null;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador trabajador = controlEmpresa.buscarTrabajadorPorCodigo(codigo);
            if (trabajador == null) {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
                return null;
            }
            return trabajador;
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
            return null;
        }
    }

    private void registrarPedido() {
        Trabajador trabajador = obtenerTrabajador();
        if (trabajador == null) {
            return;
        }
        String bebida = campoBebida.getText().trim();
        String hora = campoHora.getText().trim();

        if (bebida.equals("") || hora.equals("")) {
            etiquetaMensaje.setText("Debe indicar la bebida y la hora.");
            return;
        }

        boolean ok = Cafeteria.registrarPedido(trabajador, bebida, hora);
        if (ok) {
            etiquetaMensaje.setText("Pedido registrado correctamente.");
        } else {
            etiquetaMensaje.setText("No se pudo registrar el pedido.");
        }
        mostrarPedidos();
    }

    private void cancelarPedido() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código para cancelar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            boolean ok = Cafeteria.cancelarPedido(codigo);
            if (ok) {
                etiquetaMensaje.setText("Pedido cancelado.");
            } else {
                etiquetaMensaje.setText("El trabajador no tenía pedido registrado.");
            }
            mostrarPedidos();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido.");
        }
    }

    private void mostrarPedidos() {
        String texto = Cafeteria.mostrarPedidos();
        areaSalida.setText(texto);
    }

    public JPanel obtenerPanel() {
        return panelSalida;
    }
    
}
