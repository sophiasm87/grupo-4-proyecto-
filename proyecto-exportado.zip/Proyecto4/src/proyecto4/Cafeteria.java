/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class Cafeteria {
     private int codigoTrabajadorPedido1;
    private int codigoTrabajadorPedido2;
    private int codigoTrabajadorPedido3;
    private int codigoTrabajadorPedido4;
    private int codigoTrabajadorPedido5;

    private String bebidaPedido1;
    private String bebidaPedido2;
    private String bebidaPedido3;
    private String bebidaPedido4;
    private String bebidaPedido5;

    private String horaPedido1;
    private String horaPedido2;
    private String horaPedido3;
    private String horaPedido4;
    private String horaPedido5;

    public Cafeteria() {
        codigoTrabajadorPedido1 = 0;
        codigoTrabajadorPedido2 = 0;
        codigoTrabajadorPedido3 = 0;
        codigoTrabajadorPedido4 = 0;
        codigoTrabajadorPedido5 = 0;
    }

    public boolean registrarPedido(Trabajador trabajador, String bebida, String hora) {

        int codigo = trabajador.getCodigoTrabajador();

        if (codigoTrabajadorPedido1 == 0) {
            codigoTrabajadorPedido1 = codigo;
            bebidaPedido1 = bebida;
            horaPedido1 = hora;
            return true;
        }

        if (codigoTrabajadorPedido2 == 0) {
            codigoTrabajadorPedido2 = codigo;
            bebidaPedido2 = bebida;
            horaPedido2 = hora;
            return true;
        }

        if (codigoTrabajadorPedido3 == 0) {
            codigoTrabajadorPedido3 = codigo;
            bebidaPedido3 = bebida;
            horaPedido3 = hora;
            return true;
        }

        if (codigoTrabajadorPedido4 == 0) {
            codigoTrabajadorPedido4 = codigo;
            bebidaPedido4 = bebida;
            horaPedido4 = hora;
            return true;
        }

        if (codigoTrabajadorPedido5 == 0) {
            codigoTrabajadorPedido5 = codigo;
            bebidaPedido5 = bebida;
            horaPedido5 = hora;
            return true;
        }

        return false; 
    }

    public boolean cancelarPedido(int codigoTrabajador) {

        if (codigoTrabajadorPedido1 == codigoTrabajador) {
            codigoTrabajadorPedido1 = 0;
            bebidaPedido1 = null;
            horaPedido1 = null;
            return true;
        }

        if (codigoTrabajadorPedido2 == codigoTrabajador) {
            codigoTrabajadorPedido2 = 0;
            bebidaPedido2 = null;
            horaPedido2 = null;
            return true;
        }

        if (codigoTrabajadorPedido3 == codigoTrabajador) {
            codigoTrabajadorPedido3 = 0;
            bebidaPedido3 = null;
            horaPedido3 = null;
            return true;
        }

        if (codigoTrabajadorPedido4 == codigoTrabajador) {
            codigoTrabajadorPedido4 = 0;
            bebidaPedido4 = null;
            horaPedido4 = null;
            return true;
        }

        if (codigoTrabajadorPedido5 == codigoTrabajador) {
            codigoTrabajadorPedido5 = 0;
            bebidaPedido5 = null;
            horaPedido5 = null;
            return true;
        }

        return false;
    }

    public String mostrarPedidos() {

        String texto = "=== Pedidos registrados en cafetería ===\n\n";

        boolean hayPedidos = false;

        if (codigoTrabajadorPedido1 != 0) {
            texto = texto + "Trabajador " + codigoTrabajadorPedido1 + " - Bebida: " + bebidaPedido1 + " - Hora: " + horaPedido1 + "\n";
            hayPedidos = true;
        }

        if (codigoTrabajadorPedido2 != 0) {
            texto = texto + "Trabajador " + codigoTrabajadorPedido2 + " - Bebida: " + bebidaPedido2 + " - Hora: " + horaPedido2 + "\n";
            hayPedidos = true;
        }

        if (codigoTrabajadorPedido3 != 0) {
            texto = texto + "Trabajador " + codigoTrabajadorPedido3 + " - Bebida: " + bebidaPedido3 + " - Hora: " + horaPedido3 + "\n";
            hayPedidos = true;
        }

        if (codigoTrabajadorPedido4 != 0) {
            texto = texto + "Trabajador " + codigoTrabajadorPedido4 + " - Bebida: " + bebidaPedido4 + " - Hora: " + horaPedido4 + "\n";
            hayPedidos = true;
        }

        if (codigoTrabajadorPedido5 != 0) {
            texto = texto + "Trabajador " + codigoTrabajadorPedido5 + " - Bebida: " + bebidaPedido5 + " - Hora: " + horaPedido5 + "\n";
            hayPedidos = true;
        }

        if (!hayPedidos) {
            texto = texto + "No hay pedidos registrados.\n";
        }

        return texto;
    }
}
