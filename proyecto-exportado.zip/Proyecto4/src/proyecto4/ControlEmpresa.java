/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class ControlEmpresa {

    private Trabajador trabajador1;
    private Trabajador trabajador2;
    private Trabajador trabajador3;
    private Trabajador trabajador4;
    private Trabajador trabajador5;

    public ControlEmpresa() {
    }

    public boolean registrarTrabajador(Trabajador nuevo) {

        if (trabajador1 == null) {
            trabajador1 = nuevo;
            return true;
        }

        if (trabajador2 == null) {
            trabajador2 = nuevo;
            return true;
        }

        if (trabajador3 == null) {
            trabajador3 = nuevo;
            return true;
        }

        if (trabajador4 == null) {
            trabajador4 = nuevo;
            return true;
        }

        if (trabajador5 == null) {
            trabajador5 = nuevo;
            return true;
        }

        return false; 
    }

    public Trabajador buscarTrabajadorPorCodigo(int codigoBuscado) {

        if (trabajador1 != null && trabajador1.getCodigoTrabajador() == codigoBuscado) {
            return trabajador1;
        }

        if (trabajador2 != null && trabajador2.getCodigoTrabajador() == codigoBuscado) {
            return trabajador2;
        }

        if (trabajador3 != null && trabajador3.getCodigoTrabajador() == codigoBuscado) {
            return trabajador3;
        }

        if (trabajador4 != null && trabajador4.getCodigoTrabajador() == codigoBuscado) {
            return trabajador4;
        }

        if (trabajador5 != null && trabajador5.getCodigoTrabajador() == codigoBuscado) {
            return trabajador5;
        }

        return null;
    }

    public boolean eliminarTrabajador(int codigoAEliminar) {

        if (trabajador1 != null && trabajador1.getCodigoTrabajador() == codigoAEliminar) {
            trabajador1 = null;
            return true;
        }

        if (trabajador2 != null && trabajador2.getCodigoTrabajador() == codigoAEliminar) {
            trabajador2 = null;
            return true;
        }

        if (trabajador3 != null && trabajador3.getCodigoTrabajador() == codigoAEliminar) {
            trabajador3 = null;
            return true;
        }

        if (trabajador4 != null && trabajador4.getCodigoTrabajador() == codigoAEliminar) {
            trabajador4 = null;
            return true;
        }

        if (trabajador5 != null && trabajador5.getCodigoTrabajador() == codigoAEliminar) {
            trabajador5 = null;
            return true;
        }

        return false;
    }
}

