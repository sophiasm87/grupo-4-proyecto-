/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author sophi
 */
public class VentanaCine {
     private JPanel panelSalida;
    private ControlEmpresa controlEmpresa;
    private Cine Cine;

    private JTextField campoCodigo;
    private JTextField campoFila;
    private JTextField campoColumna;
    private JTextArea areaSala;
    private JLabel etiquetaMensaje;

    public VentanaCine(ControlEmpresa controlEmpresaRecibido, Cine moduloCineRecibido) {
        controlEmpresa = controlEmpresaRecibido;
        Cine = moduloCineRecibido;
        crearComponentes();
    }

    private void crearComponentes() {
        panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel titulo = new JLabel("Módulo de Cine");
        titulo.setBounds(370, 10, 200, 30);
        panelSalida.add(titulo);

        JLabel labelCodigo = new JLabel("Código trabajador:");
        labelCodigo.setBounds(30, 60, 130, 25);
        panelSalida.add(labelCodigo);

        campoCodigo = new JTextField();
        campoCodigo.setBounds(160, 60, 80, 25);
        panelSalida.add(campoCodigo);

        JLabel labelFila = new JLabel("Fila (A - E):");
        labelFila.setBounds(260, 60, 90, 25);
        panelSalida.add(labelFila);

        campoFila = new JTextField();
        campoFila.setBounds(340, 60, 40, 25);
        panelSalida.add(campoFila);

        JLabel labelColumna = new JLabel("Columna (1 - 5):");
        labelColumna.setBounds(400, 60, 110, 25);
        panelSalida.add(labelColumna);

        campoColumna = new JTextField();
        campoColumna.setBounds(510, 60, 40, 25);
        panelSalida.add(campoColumna);

        JButton botonReservar = new JButton("Reservar asiento");
        botonReservar.setBounds(570, 60, 150, 25);
        panelSalida.add(botonReservar);

        JButton botonCancelar = new JButton("Cancelar asiento");
        botonCancelar.setBounds(730, 60, 150, 25);
        panelSalida.add(botonCancelar);

        JButton botonVerSala = new JButton("Ver sala");
        botonVerSala.setBounds(30, 100, 120, 25);
        panelSalida.add(botonVerSala);

        etiquetaMensaje = new JLabel(" ");
        etiquetaMensaje.setBounds(170, 100, 700, 25);
        panelSalida.add(etiquetaMensaje);

        areaSala = new JTextArea();
        areaSala.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaSala);
        scroll.setBounds(30, 140, 850, 380);
        panelSalida.add(scroll);

        botonReservar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reservarAsiento();
            }
        });

        botonCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarAsiento();
            }
        });

        botonVerSala.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarSala();
            }
        });

        mostrarSala();
    }

    private Trabajador obtenerTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código del trabajador.");
            return null;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador trabajador = controlEmpresa.buscarTrabajadorPorCodigo(codigo);
            if (trabajador == null) {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
                return null;
            }
            return trabajador;
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
            return null;
        }
    }

    private void reservarAsiento() {
        Trabajador trabajador = obtenerTrabajador();
        if (trabajador == null) {
            return;
        }

        String fila = campoFila.getText().trim();
        String textoColumna = campoColumna.getText().trim();

        if (fila.equals("") || textoColumna.equals("")) {
            etiquetaMensaje.setText("Debe indicar fila y columna.");
            return;
        }

        try {
            int columna = Integer.parseInt(textoColumna);
            boolean ok = Cine.reservarAsiento(fila, columna, trabajador);
            if (ok) {
                etiquetaMensaje.setText("Asiento reservado correctamente.");
            } else {
                etiquetaMensaje.setText("No se pudo reservar (asiento ocupado, fila/columna inválida o ya tiene asiento).");
            }
            mostrarSala();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Columna inválida (debe ser número).");
        }
    }

    private void cancelarAsiento() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código para cancelar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            boolean ok = Cine.cancelarAsiento(codigo);
            if (ok) {
                etiquetaMensaje.setText("Asiento cancelado.");
            } else {
                etiquetaMensaje.setText("Este trabajador no tenía asiento reservado.");
            }
            mostrarSala();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido.");
        }
    }

    private void mostrarSala() {
        String texto = Cine.mostrarSala();
        areaSala.setText(texto);
    }

    public JPanel obtenerPanel() {
        return panelSalida;
    }
    
}
