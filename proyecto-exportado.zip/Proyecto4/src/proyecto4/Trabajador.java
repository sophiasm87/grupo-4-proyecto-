/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class Trabajador {
 private int codigoTrabajador;
    private String nombreCompletoTrabajador;
    private String departamentoTrabajador;

    public Trabajador() {
    }

    public Trabajador(int codigoTrabajadorRecibido, String nombreCompletoRecibido, String departamentoRecibido) {
        codigoTrabajador = codigoTrabajadorRecibido;
        nombreCompletoTrabajador = nombreCompletoRecibido;
        departamentoTrabajador = departamentoRecibido;
    }

    public int getCodigoTrabajador() {
        return codigoTrabajador;
    }

    public void setCodigoTrabajador(int nuevoCodigoTrabajador) {
        codigoTrabajador = nuevoCodigoTrabajador;
    }

    public String getNombreCompletoTrabajador() {
        return nombreCompletoTrabajador;
    }

    public void setNombreCompletoTrabajador(String nuevoNombreCompletoTrabajador) {
        nombreCompletoTrabajador = nuevoNombreCompletoTrabajador;
    }

    public String getDepartamentoTrabajador() {
        return departamentoTrabajador;
    }

    public void setDepartamentoTrabajador(String nuevoDepartamentoTrabajador) {
        departamentoTrabajador = nuevoDepartamentoTrabajador;
    }   

    String getNombreComplepletoTrabajador() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
