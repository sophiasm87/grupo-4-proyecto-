/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author sophi
 */
public class VentanaGym {
      private JPanel panelSalida;
    private ControlEmpresa controlEmpresa;
    private Gimnasio Gimnasio;

    private JTextField campoCodigo;
    private JTextField campoHora;
    private JTextArea areaSalida;
    private JLabel etiquetaMensaje;

    public VentanaGym(ControlEmpresa controlEmpresaRecibido, Gimnasio moduloGimnasioRecibido) {
        controlEmpresa = controlEmpresaRecibido;
        Gimnasio = moduloGimnasioRecibido;
        crearComponentes();
    }

    private void crearComponentes() {
        panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel titulo = new JLabel("Módulo de Gimnasio");
        titulo.setBounds(350, 10, 200, 30);
        panelSalida.add(titulo);

        JLabel labelCodigo = new JLabel("Código trabajador:");
        labelCodigo.setBounds(30, 60, 130, 25);
        panelSalida.add(labelCodigo);

        campoCodigo = new JTextField();
        campoCodigo.setBounds(160, 60, 80, 25);
        panelSalida.add(campoCodigo);

        JLabel labelHora = new JLabel("Número de hora (1, 2 o 3):");
        labelHora.setBounds(260, 60, 180, 25);
        panelSalida.add(labelHora);

        campoHora = new JTextField();
        campoHora.setBounds(440, 60, 40, 25);
        panelSalida.add(campoHora);

        JLabel labelHorasInfo = new JLabel("Hora 1 = 2 pm | Hora 2 = 3 pm | Hora 3 = 4 pm");
        labelHorasInfo.setBounds(30, 90, 450, 25);
        panelSalida.add(labelHorasInfo);

        JButton botonReservar = new JButton("Reservar");
        botonReservar.setBounds(30, 130, 120, 25);
        panelSalida.add(botonReservar);

        JButton botonCancelar = new JButton("Cancelar reserva");
        botonCancelar.setBounds(170, 130, 160, 25);
        panelSalida.add(botonCancelar);

        JButton botonVer = new JButton("Ver reservas");
        botonVer.setBounds(350, 130, 130, 25);
        panelSalida.add(botonVer);

        etiquetaMensaje = new JLabel(" ");
        etiquetaMensaje.setBounds(30, 165, 600, 25);
        panelSalida.add(etiquetaMensaje);

        areaSalida = new JTextArea();
        areaSalida.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaSalida);
        scroll.setBounds(30, 200, 800, 320);
        panelSalida.add(scroll);

        botonReservar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reservar();
            }
        });

        botonCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelar();
            }
        });

        botonVer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarReservas();
            }
        });

        mostrarReservas();
    }

    private Trabajador obtenerTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código del trabajador.");
            return null;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador trabajador = controlEmpresa.buscarTrabajadorPorCodigo(codigo);
            if (trabajador == null) {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
                return null;
            }
            return trabajador;
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
            return null;
        }
    }

    private void reservar() {
        Trabajador trabajador = obtenerTrabajador();
        if (trabajador == null) {
            return;
        }
        String textoHora = campoHora.getText().trim();
        if (textoHora.equals("")) {
            etiquetaMensaje.setText("Debe indicar la hora (1, 2 o 3).");
            return;
        }
        try {
            int numeroHora = Integer.parseInt(textoHora);
            boolean ok = Gimnasio.reservarEspacio(trabajador.getCodigoTrabajador(), trabajador, numeroHora);
            if (ok) {
                etiquetaMensaje.setText("Reserva realizada correctamente.");
            } else {
                etiquetaMensaje.setText("No se pudo reservar (ya tiene reserva o sin espacio).");
            }
            mostrarReservas();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Número de hora inválido.");
        }
    }

    private void cancelar() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir el código para cancelar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            boolean ok = Gimnasio.cancelarReserva(codigo);
            if (ok) {
                etiquetaMensaje.setText("Reserva cancelada.");
            } else {
                etiquetaMensaje.setText("El trabajador no tenía reserva registrada.");
            }
            mostrarReservas();
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido.");
        }
    }

    private void mostrarReservas() {
        String texto = Gimnasio.mostrarReservas();
        areaSalida.setText(texto);
    }

    public JPanel obtenerPanel() {
        return panelSalida;
    }
    
}
