/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class Cine {

    // FILA A
    private Trabajador asientoA1;
    private Trabajador asientoA2;
    private Trabajador asientoA3;
    private Trabajador asientoA4;
    private Trabajador asientoA5;

    // FILA B
    private Trabajador asientoB1;
    private Trabajador asientoB2;
    private Trabajador asientoB3;
    private Trabajador asientoB4;
    private Trabajador asientoB5;

    // FILA C
    private Trabajador asientoC1;
    private Trabajador asientoC2;
    private Trabajador asientoC3;
    private Trabajador asientoC4;
    private Trabajador asientoC5;

    // FILA D
    private Trabajador asientoD1;
    private Trabajador asientoD2;
    private Trabajador asientoD3;
    private Trabajador asientoD4;
    private Trabajador asientoD5;

    // FILA E
    private Trabajador asientoE1;
    private Trabajador asientoE2;
    private Trabajador asientoE3;
    private Trabajador asientoE4;
    private Trabajador asientoE5;

    public Cine() {

    }

    public boolean reservarAsiento(String fila, int columna, Trabajador trabajador) {

        // Evitar doble reserva en la sala
        if (tieneAsiento(trabajador.getCodigoTrabajador())) {
            return false;
        }

        fila = fila.toUpperCase();

        // Fila A
        if (fila.equals("A")) {
            return reservarEnFilaA(columna, trabajador);
        }

        // Fila B
        if (fila.equals("B")) {
            return reservarEnFilaB(columna, trabajador);
        }

        // Fila C
        if (fila.equals("C")) {
            return reservarEnFilaC(columna, trabajador);
        }

        // Fila D
        if (fila.equals("D")) {
            return reservarEnFilaD(columna, trabajador);
        }

        // Fila E
        if (fila.equals("E")) {
            return reservarEnFilaE(columna, trabajador);
        }

        return false; // fila inválida
    }

    private boolean reservarEnFilaA(int c, Trabajador t) {
        if (c == 1 && asientoA1 == null) { asientoA1 = t; return true; }
        if (c == 2 && asientoA2 == null) { asientoA2 = t; return true; }
        if (c == 3 && asientoA3 == null) { asientoA3 = t; return true; }
        if (c == 4 && asientoA4 == null) { asientoA4 = t; return true; }
        if (c == 5 && asientoA5 == null) { asientoA5 = t; return true; }
        return false;
    }

    private boolean reservarEnFilaB(int c, Trabajador t) {
        if (c == 1 && asientoB1 == null) { asientoB1 = t; return true; }
        if (c == 2 && asientoB2 == null) { asientoB2 = t; return true; }
        if (c == 3 && asientoB3 == null) { asientoB3 = t; return true; }
        if (c == 4 && asientoB4 == null) { asientoB4 = t; return true; }
        if (c == 5 && asientoB5 == null) { asientoB5 = t; return true; }
        return false;
    }

    private boolean reservarEnFilaC(int c, Trabajador t) {
        if (c == 1 && asientoC1 == null) { asientoC1 = t; return true; }
        if (c == 2 && asientoC2 == null) { asientoC2 = t; return true; }
        if (c == 3 && asientoC3 == null) { asientoC3 = t; return true; }
        if (c == 4 && asientoC4 == null) { asientoC4 = t; return true; }
        if (c == 5 && asientoC5 == null) { asientoC5 = t; return true; }
        return false;
    }

    private boolean reservarEnFilaD(int c, Trabajador t) {
        if (c == 1 && asientoD1 == null) { asientoD1 = t; return true; }
        if (c == 2 && asientoD2 == null) { asientoD2 = t; return true; }
        if (c == 3 && asientoD3 == null) { asientoD3 = t; return true; }
        if (c == 4 && asientoD4 == null) { asientoD4 = t; return true; }
        if (c == 5 && asientoD5 == null) { asientoD5 = t; return true; }
        return false;
    }

    private boolean reservarEnFilaE(int c, Trabajador t) {
        if (c == 1 && asientoE1 == null) { asientoE1 = t; return true; }
        if (c == 2 && asientoE2 == null) { asientoE2 = t; return true; }
        if (c == 3 && asientoE3 == null) { asientoE3 = t; return true; }
        if (c == 4 && asientoE4 == null) { asientoE4 = t; return true; }
        if (c == 5 && asientoE5 == null) { asientoE5 = t; return true; }
        return false;
    }

    public boolean tieneAsiento(int codigo) {

        if (asientoA1 != null && asientoA1.getCodigoTrabajador() == codigo) return true;
        if (asientoA2 != null && asientoA2.getCodigoTrabajador() == codigo) return true;
        if (asientoA3 != null && asientoA3.getCodigoTrabajador() == codigo) return true;
        if (asientoA4 != null && asientoA4.getCodigoTrabajador() == codigo) return true;
        if (asientoA5 != null && asientoA5.getCodigoTrabajador() == codigo) return true;

        if (asientoB1 != null && asientoB1.getCodigoTrabajador() == codigo) return true;
        if (asientoB2 != null && asientoB2.getCodigoTrabajador() == codigo) return true;
        if (asientoB3 != null && asientoB3.getCodigoTrabajador() == codigo) return true;
        if (asientoB4 != null && asientoB4.getCodigoTrabajador() == codigo) return true;
        if (asientoB5 != null && asientoB5.getCodigoTrabajador() == codigo) return true;

        if (asientoC1 != null && asientoC1.getCodigoTrabajador() == codigo) return true;
        if (asientoC2 != null && asientoC2.getCodigoTrabajador() == codigo) return true;
        if (asientoC3 != null && asientoC3.getCodigoTrabajador() == codigo) return true;
        if (asientoC4 != null && asientoC4.getCodigoTrabajador() == codigo) return true;
        if (asientoC5 != null && asientoC5.getCodigoTrabajador() == codigo) return true;

        if (asientoD1 != null && asientoD1.getCodigoTrabajador() == codigo) return true;
        if (asientoD2 != null && asientoD2.getCodigoTrabajador() == codigo) return true;
        if (asientoD3 != null && asientoD3.getCodigoTrabajador() == codigo) return true;
        if (asientoD4 != null && asientoD4.getCodigoTrabajador() == codigo) return true;
        if (asientoD5 != null && asientoD5.getCodigoTrabajador() == codigo) return true;

        if (asientoE1 != null && asientoE1.getCodigoTrabajador() == codigo) return true;
        if (asientoE2 != null && asientoE2.getCodigoTrabajador() == codigo) return true;
        if (asientoE3 != null && asientoE3.getCodigoTrabajador() == codigo) return true;
        if (asientoE4 != null && asientoE4.getCodigoTrabajador() == codigo) return true;
        if (asientoE5 != null && asientoE5.getCodigoTrabajador() == codigo) return true;

        return false;
    }

    public boolean cancelarAsiento(int codigo) {

        if (asientoA1 != null && asientoA1.getCodigoTrabajador() == codigo) { asientoA1 = null; return true; }
        if (asientoA2 != null && asientoA2.getCodigoTrabajador() == codigo) { asientoA2 = null; return true; }
        if (asientoA3 != null && asientoA3.getCodigoTrabajador() == codigo) { asientoA3 = null; return true; }
        if (asientoA4 != null && asientoA4.getCodigoTrabajador() == codigo) { asientoA4 = null; return true; }
        if (asientoA5 != null && asientoA5.getCodigoTrabajador() == codigo) { asientoA5 = null; return true; }

        if (asientoB1 != null && asientoB1.getCodigoTrabajador() == codigo) { asientoB1 = null; return true; }
        if (asientoB2 != null && asientoB2.getCodigoTrabajador() == codigo) { asientoB2 = null; return true; }
        if (asientoB3 != null && asientoB3.getCodigoTrabajador() == codigo) { asientoB3 = null; return true; }
        if (asientoB4 != null && asientoB4.getCodigoTrabajador() == codigo) { asientoB4 = null; return true; }
        if (asientoB5 != null && asientoB5.getCodigoTrabajador() == codigo) { asientoB5 = null; return true; }

        if (asientoC1 != null && asientoC1.getCodigoTrabajador() == codigo) { asientoC1 = null; return true; }
        if (asientoC2 != null && asientoC2.getCodigoTrabajador() == codigo) { asientoC2 = null; return true; }
        if (asientoC3 != null && asientoC3.getCodigoTrabajador() == codigo) { asientoC3 = null; return true; }
        if (asientoC4 != null && asientoC4.getCodigoTrabajador() == codigo) { asientoC4 = null; return true; }
        if (asientoC5 != null && asientoC5.getCodigoTrabajador() == codigo) { asientoC5 = null; return true; }

        if (asientoD1 != null && asientoD1.getCodigoTrabajador() == codigo) { asientoD1 = null; return true; }
        if (asientoD2 != null && asientoD2.getCodigoTrabajador() == codigo) { asientoD2 = null; return true; }
        if (asientoD3 != null && asientoD3.getCodigoTrabajador() == codigo) { asientoD3 = null; return true; }
        if (asientoD4 != null && asientoD4.getCodigoTrabajador() == codigo) { asientoD4 = null; return true; }
        if (asientoD5 != null && asientoD5.getCodigoTrabajador() == codigo) { asientoD5 = null; return true; }

        if (asientoE1 != null && asientoE1.getCodigoTrabajador() == codigo) { asientoE1 = null; return true; }
        if (asientoE2 != null && asientoE2.getCodigoTrabajador() == codigo) { asientoE2 = null; return true; }
        if (asientoE3 != null && asientoE3.getCodigoTrabajador() == codigo) { asientoE3 = null; return true; }
        if (asientoE4 != null && asientoE4.getCodigoTrabajador() == codigo) { asientoE4 = null; return true; }
        if (asientoE5 != null && asientoE5.getCodigoTrabajador() == codigo) { asientoE5 = null; return true; }

        return false;
    }

    public String mostrarSala() {

        String texto = "             PANTALLA\n\n";
        texto = texto + "     1   2   3   4   5\n";

        texto = texto + filaToTexto("A", asientoA1, asientoA2, asientoA3, asientoA4, asientoA5);
        texto = texto + filaToTexto("B", asientoB1, asientoB2, asientoB3, asientoB4, asientoB5);
        texto = texto + filaToTexto("C", asientoC1, asientoC2, asientoC3, asientoC4, asientoC5);
        texto = texto + filaToTexto("D", asientoD1, asientoD2, asientoD3, asientoD4, asientoD5);
        texto = texto + filaToTexto("E", asientoE1, asientoE2, asientoE3, asientoE4, asientoE5);

        return texto;
    }

    private String filaToTexto(String letra, Trabajador a1, Trabajador a2, Trabajador a3, Trabajador a4, Trabajador a5) {

        String texto = letra + " :  ";

        texto = texto + (a1 == null ? "L   " : "O   ");
        texto = texto + (a2 == null ? "L   " : "O   ");
        texto = texto + (a3 == null ? "L   " : "O   ");
        texto = texto + (a4 == null ? "L   " : "O   ");
        texto = texto + (a5 == null ? "L   " : "O   ");

        texto = texto + "\n";

        return texto;
    }
}

