/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

/**
 *
 * @author sophi
 */
public class Gimnasio {

    private Trabajador trabajadorHora1Espacio1;
    private Trabajador trabajadorHora1Espacio2;

    private Trabajador trabajadorHora2Espacio1;
    private Trabajador trabajadorHora2Espacio2;

    private Trabajador trabajadorHora3Espacio1;
    private Trabajador trabajadorHora3Espacio2;

    public Gimnasio() {
  
    }

    public boolean reservarEspacio(int codigoTrabajador, Trabajador trabajador, int numeroHora) {


        if (yaTieneReserva(codigoTrabajador)) {
            return false;
        }

        // HORA 1
        if (numeroHora == 1) {
            if (trabajadorHora1Espacio1 == null) {
                trabajadorHora1Espacio1 = trabajador;
                return true;
            }
            if (trabajadorHora1Espacio2 == null) {
                trabajadorHora1Espacio2 = trabajador;
                return true;
            }
            return false;
        }

        // HORA 2
        if (numeroHora == 2) {
            if (trabajadorHora2Espacio1 == null) {
                trabajadorHora2Espacio1 = trabajador;
                return true;
            }
            if (trabajadorHora2Espacio2 == null) {
                trabajadorHora2Espacio2 = trabajador;
                return true;
            }
            return false;
        }

        // HORA 3
        if (numeroHora == 3) {
            if (trabajadorHora3Espacio1 == null) {
                trabajadorHora3Espacio1 = trabajador;
                return true;
            }
            if (trabajadorHora3Espacio2 == null) {
                trabajadorHora3Espacio2 = trabajador;
                return true;
            }
            return false;
        }

        return false; 
    }

    public boolean yaTieneReserva(int codigo) {

        if (trabajadorHora1Espacio1 != null && trabajadorHora1Espacio1.getCodigoTrabajador() == codigo) {
            return true;
        }
        if (trabajadorHora1Espacio2 != null && trabajadorHora1Espacio2.getCodigoTrabajador() == codigo) {
            return true;
        }

        if (trabajadorHora2Espacio1 != null && trabajadorHora2Espacio1.getCodigoTrabajador() == codigo) {
            return true;
        }
        if (trabajadorHora2Espacio2 != null && trabajadorHora2Espacio2.getCodigoTrabajador() == codigo) {
            return true;
        }

        if (trabajadorHora3Espacio1 != null && trabajadorHora3Espacio1.getCodigoTrabajador() == codigo) {
            return true;
        }
        if (trabajadorHora3Espacio2 != null && trabajadorHora3Espacio2.getCodigoTrabajador() == codigo) {
            return true;
        }

        return false;
    }

    public boolean cancelarReserva(int codigo) {

        if (trabajadorHora1Espacio1 != null && trabajadorHora1Espacio1.getCodigoTrabajador() == codigo) {
            trabajadorHora1Espacio1 = null;
            return true;
        }
        if (trabajadorHora1Espacio2 != null && trabajadorHora1Espacio2.getCodigoTrabajador() == codigo) {
            trabajadorHora1Espacio2 = null;
            return true;
        }

        if (trabajadorHora2Espacio1 != null && trabajadorHora2Espacio1.getCodigoTrabajador() == codigo) {
            trabajadorHora2Espacio1 = null;
            return true;
        }
        if (trabajadorHora2Espacio2 != null && trabajadorHora2Espacio2.getCodigoTrabajador() == codigo) {
            trabajadorHora2Espacio2 = null;
            return true;
        }

        if (trabajadorHora3Espacio1 != null && trabajadorHora3Espacio1.getCodigoTrabajador() == codigo) {
            trabajadorHora3Espacio1 = null;
            return true;
        }
        if (trabajadorHora3Espacio2 != null && trabajadorHora3Espacio2.getCodigoTrabajador() == codigo) {
            trabajadorHora3Espacio2 = null;
            return true;
        }

        return false;
    }

    public String mostrarReservas() {

        String texto = "Reservas del Gimnasio \n\n";

        texto = texto + "Hora 1 (2 pm):\n";
        if (trabajadorHora1Espacio1 != null) {
            texto = texto + "  Espacio 1: " + trabajadorHora1Espacio1.getNombreCompletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 1: Libre\n";
        }
        if (trabajadorHora1Espacio2 != null) {
            texto = texto + "  Espacio 2: " + trabajadorHora1Espacio2.getNombreCompletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 2: Libre\n";
        }

        texto = texto + "\nHora 2 (3 pm):\n";
        if (trabajadorHora2Espacio1 != null) {
            texto = texto + "  Espacio 1: " + trabajadorHora2Espacio1.getNombreCompletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 1: Libre\n";
        }
        if (trabajadorHora2Espacio2 != null) {
            texto = texto + "  Espacio 2: " + trabajadorHora2Espacio2.getNombreCompletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 2: Libre\n";
        }

        texto = texto + "\nHora 3 (4 pm):\n";
        if (trabajadorHora3Espacio1 != null) {
            texto = texto + "  Espacio 1: " + trabajadorHora3Espacio1.getNombreComplepletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 1: Libre\n";
        }
        if (trabajadorHora3Espacio2 != null) {
            texto = texto + "  Espacio 2: " + trabajadorHora3Espacio2.getNombreCompletoTrabajador() + "\n";
        } else {
            texto = texto + "  Espacio 2: Libre\n";
        }

        return texto;
    }
}

