/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author sophi
 */
public class VentanaTrabajadores {
     private JPanel panelSalida;
    private ControlEmpresa controlEmpresa;

    private JTextField campoCodigo;
    private JTextField campoNombre;
    private JTextField campoDepartamento;
    private JTextArea areaResultado;
    private JLabel etiquetaMensaje;

    public VentanaTrabajadores(ControlEmpresa controlEmpresaRecibido) {
        controlEmpresa = controlEmpresaRecibido;
        crearComponentes();
    }

    private void crearComponentes() {
        panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel titulo = new JLabel("Módulo de Trabajadores");
        titulo.setBounds(320, 10, 250, 30);
        panelSalida.add(titulo);

        JLabel labelCodigo = new JLabel("Código:");
        labelCodigo.setBounds(30, 60, 80, 25);
        panelSalida.add(labelCodigo);

        campoCodigo = new JTextField();
        campoCodigo.setBounds(110, 60, 80, 25);
        panelSalida.add(campoCodigo);

        JLabel labelNombre = new JLabel("Nombre completo:");
        labelNombre.setBounds(220, 60, 130, 25);
        panelSalida.add(labelNombre);

        campoNombre = new JTextField();
        campoNombre.setBounds(350, 60, 200, 25);
        panelSalida.add(campoNombre);

        JLabel labelDepartamento = new JLabel("Departamento:");
        labelDepartamento.setBounds(580, 60, 100, 25);
        panelSalida.add(labelDepartamento);

        campoDepartamento = new JTextField();
        campoDepartamento.setBounds(670, 60, 150, 25);
        panelSalida.add(campoDepartamento);

        JButton botonRegistrar = new JButton("Registrar");
        botonRegistrar.setBounds(30, 100, 120, 25);
        panelSalida.add(botonRegistrar);

        JButton botonBuscar = new JButton("Buscar");
        botonBuscar.setBounds(170, 100, 120, 25);
        panelSalida.add(botonBuscar);

        JButton botonEliminar = new JButton("Eliminar");
        botonEliminar.setBounds(310, 100, 120, 25);
        panelSalida.add(botonEliminar);

        JButton botonLimpiar = new JButton("Limpiar campos");
        botonLimpiar.setBounds(450, 100, 150, 25);
        panelSalida.add(botonLimpiar);

        etiquetaMensaje = new JLabel(" ");
        etiquetaMensaje.setBounds(30, 135, 600, 25);
        panelSalida.add(etiquetaMensaje);

        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaResultado);
        scroll.setBounds(30, 170, 800, 350);
        panelSalida.add(scroll);

        botonRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarTrabajador();
            }
        });

        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarTrabajador();
            }
        });

        botonEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarTrabajador();
            }
        });

        botonLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                campoCodigo.setText("");
                campoNombre.setText("");
                campoDepartamento.setText("");
                etiquetaMensaje.setText("Campos limpiados.");
                areaResultado.setText("");
            }
        });
    }

    private void registrarTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        String nombre = campoNombre.getText().trim();
        String departamento = campoDepartamento.getText().trim();

        if (textoCodigo.equals("") || nombre.equals("") || departamento.equals("")) {
            etiquetaMensaje.setText("Debe llenar todos los datos.");
            return;
        }

        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador nuevo = new Trabajador(codigo, nombre, departamento);
            boolean seRegistro = controlEmpresa.registrarTrabajador(nuevo);

            if (seRegistro) {
                etiquetaMensaje.setText("Trabajador registrado correctamente.");
            } else {
                etiquetaMensaje.setText("No se pudo registrar (no hay espacio).");
            }
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
        }
    }

    private void buscarTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir un código para buscar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            Trabajador encontrado = controlEmpresa.buscarTrabajadorPorCodigo(codigo);
            if (encontrado == null) {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
                areaResultado.setText("");
            } else {
                etiquetaMensaje.setText("Trabajador encontrado.");
                String texto = "";
                texto = texto + "Código: " + encontrado.getCodigoTrabajador() + "\n";
                texto = texto + "Nombre: " + encontrado.getNombreCompletoTrabajador() + "\n";
                texto = texto + "Departamento: " + encontrado.getDepartamentoTrabajador() + "\n";
                areaResultado.setText(texto);
                campoNombre.setText(encontrado.getNombreCompletoTrabajador());
                campoDepartamento.setText(encontrado.getDepartamentoTrabajador());
            }
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
        }
    }

    private void eliminarTrabajador() {
        String textoCodigo = campoCodigo.getText().trim();
        if (textoCodigo.equals("")) {
            etiquetaMensaje.setText("Debe escribir un código para eliminar.");
            return;
        }
        try {
            int codigo = Integer.parseInt(textoCodigo);
            boolean eliminado = controlEmpresa.eliminarTrabajador(codigo);
            if (eliminado) {
                etiquetaMensaje.setText("Trabajador eliminado.");
                areaResultado.setText("");
            } else {
                etiquetaMensaje.setText("No se encontró trabajador con ese código.");
            }
        } catch (NumberFormatException ex) {
            etiquetaMensaje.setText("Código inválido (debe ser número).");
        }
    }

    public JPanel obtenerPanel() {
        return panelSalida;
    }
    
}
